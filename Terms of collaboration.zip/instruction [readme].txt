Hello dear YouTuber!
This instruction will help you extract our video and contract from the archive and view it without any errors.

1. Click the extract button at the top of the archive
2. In the menu that appears (on the right side), left-click once on "Desktop".
3. Click the "Ok" button.
4. Close the archive and go to your desktop
5. Our document should appear on the desktop with the name Trusted Advertising Contract Agreement, open any of these files by clicking 2 times!